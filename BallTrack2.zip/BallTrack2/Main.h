#ifndef __MAIN_H__
#define __MAIN_H__

#define PROGRAM_VERSION 1
#define PROGRAM_SUBVERSION 0

#endif // __MAIN_H__
