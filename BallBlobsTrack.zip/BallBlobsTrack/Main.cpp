#include <opencv2/opencv.hpp>
#include <iostream>
#include <cstdlib>
 
using namespace cv;
using std::cout;
using std::endl;
 
int main(int argc, char **argv){

	int WHITE[6] {0, 255, 0, 30, 145, 255};
	int GREEN[6] {0, 255, 50, 255, 143, 255};
    int NOGREEN[6] {0, 255, 0, 255, 120, 255};
    int BLACK[6] {0, 255, 0, 102, 0, 60};
    int BW[6] {110, 255, 0, 111, 0, 255};

    char mainWindow[] = "Main";
    char trackbarWindow[] = "Trackbar";
    char thresholdWindow[] = "No GREEN?WHITE";
    char thresholdWindow1[] = "WHITE";
    char thresholdWindow2[] = "CUSTOM";
    char thresholdWindow3[] = "No GREEN";
    char thresholdWindow4[] = "BLACK";
    char thresholdWindow5[] = "BLACK AND WHITE";
    int min = 0, max = 1000;
    int hmin = 0, smin = 0, vmin = 0,
        hmax = 255, smax = 255, vmax = 255;
    Mat frame, HSV, threshold, blurred, threshold1, threshold2, threshold3, threshold4, threshold5;
    VideoCapture capture(0);
    
    CvMemStorage* storage = cvCreateMemStorage(0);

    //Создаем окна
    namedWindow(mainWindow, 0);
    namedWindow(trackbarWindow, 0);
    namedWindow(thresholdWindow, 0);
    namedWindow(thresholdWindow1, 0);
    namedWindow(thresholdWindow2, 0);
    namedWindow(thresholdWindow3, 0);
    namedWindow(thresholdWindow4, 0);
    namedWindow(thresholdWindow5, 0);
    
    //Создаем трэкбар
    createTrackbar("H min:", trackbarWindow, &hmin, hmax);
    createTrackbar("H max:", trackbarWindow, &hmax, hmax);
    createTrackbar("S min:", trackbarWindow, &smin, smax);
    createTrackbar("S max:", trackbarWindow, &smax, smax);
    createTrackbar("V min:", trackbarWindow, &vmin, vmax);
    createTrackbar("V max:", trackbarWindow, &vmax, vmax);
    createTrackbar("Size min:", trackbarWindow, &min, max);
    createTrackbar("Size max:", trackbarWindow, &max, max);
    
    //Открываем камеру
    capture.open(0);
    if(!capture.isOpened())
    {
        cout << "Камера не может быть открыта." << endl;
        exit(1);
    }
    
    //Запускаем цикл чтения с камеры
    for(;;){
        capture >> frame;
        cvtColor(frame, HSV, COLOR_BGR2HSV);
        medianBlur(HSV, blurred, 21);

        inRange(blurred, Scalar(hmin, smin, vmin), Scalar(hmax, smax, vmax), threshold2);
        inRange(blurred, Scalar(WHITE[0], WHITE[2], WHITE[4]), Scalar(WHITE[1], WHITE[3], WHITE[5]), threshold1);
        inRange(blurred, Scalar(GREEN[0], GREEN[2], GREEN[4]), Scalar(GREEN[1], GREEN[3], GREEN[5]), threshold3);

        inRange(blurred, Scalar(NOGREEN[0], NOGREEN[2], NOGREEN[4]), Scalar(NOGREEN[1], NOGREEN[3], NOGREEN[5]), threshold);

        inRange(blurred, Scalar(BLACK[0], BLACK[2], BLACK[4]), Scalar(BLACK[1], BLACK[3], BLACK[5]), threshold4);
        inRange(blurred, Scalar(BW[0], BW[2], BW[4]), Scalar(BW[1], BW[3], BW[5]), threshold5);
        //cvCvtColor(threshold, threshold, CV_RGB2GRAY);
		//cvCanny(threshold, threshold, 10, 100, 3);
        /*
		for (int y = 0; y < threshold5.rows; y++)
		{
			for (int x = 0; x < threshold5.cols; x++)
			{
				int value = threshold5.at<uchar>(y, x);
                if(value == 0)
                {
                	threshold5.at<uchar>(y, x) = threshold4.at<uchar>(y, x);
                }
			}
		}
        
        IplImage tmp = threshold;
        CvSeq* results = cvHoughCircles(&tmp, storage, CV_HOUGH_GRADIENT, 1, 10); 
        for( int i = 0; i < results->total; i++ ) 
        {
			float* p = (float*) cvGetSeqElem( results, i );
			CvPoint pt = cvPoint( cvRound(p[0]), cvRound(p[1]));
			cvCircle(&tmp, pt, cvRound( p[2] ), CV_RGB(0xff,0,0) );
			//circle(tmp, pt, (255,0,0), 10);
			cout<<"OOP"<<'\n';
		}
		circle(frame, Point(100, 100), 10, Scalar(255,0,0), 10);
		cvShowImage("FFF", &tmp);

		*/
		
        for(int y = 0; y < threshold.rows; y++){
            for(int x = 0; x < threshold.cols; x++){
                int value = threshold.at<uchar>(y, x);
                if(value == 255){
                    Rect rect;
                    int count = floodFill(threshold, Point(x, y), Scalar(200), &rect);
                    if(abs(rect.width - rect.height) <= rect.width / 10 and rect.width > 50){
                    rectangle(frame, rect, Scalar(255, 0, 255), 10);
                    }
                }
            }
        }
        
        
        imshow(mainWindow, frame);
        imshow(thresholdWindow, threshold);
        //imshow(thresholdWindow1, threshold1);
        //imshow(thresholdWindow2, threshold2);
        //imshow(thresholdWindow3, threshold3);
        //imshow(thresholdWindow4, threshold4);
        //imshow(thresholdWindow5, threshold5);
        if(waitKey(33) == 27) break;
    }
    return 0;
}
